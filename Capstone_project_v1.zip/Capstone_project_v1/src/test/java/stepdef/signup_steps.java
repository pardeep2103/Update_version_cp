package stepdef;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import Pages.signup_page;
import io.cucumber.java.en.*;

public class signup_steps {

    WebDriver driver;
    signup_page signup;
    WebDriverWait wait;

    @Given("the user is on the Sign Up page")
    public void openSignupPage() {
        System.setProperty("webdriver.chrome.driver", "chromedriver_v141.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.demoblaze.com");
        signup = new signup_page(driver);
        signup.clickSignupLink(); 
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    }

    @And("the user enters a valid username {string}")
    public void enterCredentials(String username) {
        signup.enterUsername(username);
    }
    @And("the user enters a valid password {string}")
    public void enterCredentials1(String password) {
        signup.enterPassword(password);
    }


    @And("the user clicks the Sign Up button")
    public void clickSignupButton() {
        signup.clickSignupButton();
    }

    @Then("the user should see a success message or be redirected to the homepage")
    public void verifySuccessMessage() {
        wait.until(ExpectedConditions.alertIsPresent()); 
        String actualMessage = driver.switchTo().alert().getText();
        String expectedMessage = "Sign up successful."; 
        Assert.assertEquals(actualMessage, expectedMessage, "Signup success message mismatch.");
        driver.switchTo().alert().accept(); 
        System.out.println(actualMessage);
        driver.quit();
    }
}